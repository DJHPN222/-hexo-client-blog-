# hexo-client

> Hexo桌面客户端

- Hexo: [Hexo home page, https://hexo.io](https://hexo.io)

## 



### 功能简介
- 文章添加
- 文章修改
- 文章删除
- 草稿功能
- 多图床支持：aliyun-oss、七牛、sm.ms、Github
- 文章搜索
- 文章按分类、标签分组展示
- 多语言支持
- 支持[Travis-CI](https://travis-ci.org/)自动部署




### Build Setup

``` bash
# install dependencies
npm install

# dev
npm run electron:serve

# build electron application for production
npm run electron:build
```
