// 一个空模版
const state = {}
const mutations = {}
const actions = {
  init (context) {
  }
}
export default {
  namespaced: true,
  state,
  mutations,
  actions
}
